<?php

// SET ERROR REPORTING
error_reporting(E_ALL ^ E_WARNING ^ E_NOTICE);
ini_set('display_errors', TRUE);

// CHECK FOR PAGE VARIABLE
if(!isset($page)) { $page = ""; }

// DEFINE SE PAGE CONSTANT
define('SE_PAGE', true);

// SET INCLUDE PATH TO ROOT OF SE
set_include_path(get_include_path() . PATH_SEPARATOR . realpath("./"));

// INITIATE SMARTY
$folder = "base";
include "include/smarty/smarty_config.php";

// INCLUDE DATABASE INFORMATION
include "include/database_config.php";

// INCLUDE CLASS/FUNCTION FILES
include "include/class_admin.php";
include "include/class_database.php";
include "include/class_datetime.php";
include "include/class_comment.php";
include "include/class_field.php";
include "include/class_hook.php";
include "include/class_language.php";
include "include/class_notify.php";
include "include/class_upload.php";
include "include/class_user.php";
include "include/class_url.php";
include "include/class_misc.php";
include "include/class_ads.php";
include "include/class_actions.php";
include "include/functions_general.php";
include "include/functions_email.php";
include "include/functions_stats.php";

// INITIATE DATABASE CONNECTION
$database = new se_database($database_host, $database_username, $database_password, $database_name);

// SET DATABASE CONSTANTS
$database->database_query("SET @SE_PRIVACY_SELF = 1, @SE_PRIVACY_FRIEND = 2, @SE_PRIVACY_FRIEND2 = 4, @SE_PRIVACY_SUBNET = 8, @SE_PRIVACY_REGISTERED = 16, @SE_PRIVACY_ANONYMOUS = 32");

// SET LANGUAGE CHARSET
$database->database_set_charset(SE_Language::info('charset'));

// GET SETTINGS
$setting = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_settings LIMIT 1"));

// CREATE URL CLASS
$url = new se_url();

// CREATE DATETIME CLASS
$datetime = new se_datetime();

// CREATE MISC CLASS
$misc = new se_misc();

// ENSURE NO SQL INJECTIONS THROUGH POST OR GET ARRAYS
$_POST = security($_POST);
$_GET = security($_GET);
$_COOKIE = security($_COOKIE);

// CHECK FOR PAGE OWNER
if(isset($_POST['user'])) { $user_username = $_POST['user']; } elseif(isset($_GET['user'])) { $user_username = $_GET['user']; } else { $user_username = ""; }
if(isset($_POST['user_id'])) { $user_id = $_POST['user_id']; } elseif(isset($_GET['user_id'])) { $user_id = $_GET['user_id']; } else { $user_id = ""; }
$owner = new se_user(Array($user_id, $user_username));

// CREATE USER OBJECT AND ATTEMPT TO LOG USER IN
$user = new se_user();
$user->user_checkCookies();

// USER IS LOGGED IN
if($user->user_exists != 0) { 

  // SET TIMEZONE IF USER IS LOGGED IN
  $global_timezone = $user->user_info[user_timezone];

// USER IS NOT LOGGED IN
} else { 

  // SEND USER TO LOGIN IF TRYING TO ACCESS USER CONTROL PANEL
  if(substr($page, 0, 5) == "user_") { header("Location: login.php?return_url=".$url->url_current()); exit(); }

  // SET TIMEZONE IF USER IS LOGGED OUT
  $global_timezone = $setting[setting_timezone]; 

  // SET VISITOR LAST ACTIVE TIME
  $database->database_query("INSERT INTO se_visitors (visitor_ip, visitor_lastactive) VALUES ('".$_SERVER['REMOTE_ADDR']."', '".time()."') ON DUPLICATE KEY UPDATE visitor_lastactive = '".time()."'");
}


// SET UP LANGUAGE VARIABLES
if(isset($_GET['lang_id']) && $setting[setting_lang_allow] == 1 && $user->user_exists != 0) {
  $user->user_info[user_language_id] = (int)$_GET['lang_id'];
  setcookie('se_language_anonymous', $user->user_info[user_language_id], time()+99999999, "/");
  $database->database_query("UPDATE se_users SET user_language_id='".$user->user_info[user_language_id]."' WHERE user_id='".$user->user_info[user_id]."'");
} elseif(isset($_GET['lang_id']) && $setting[setting_lang_anonymous]) {
  setcookie('se_language_anonymous', (int)$_GET['lang_id'], time()+99999999, "/");
  $_COOKIE['se_language_anonymous'] = (int)$_GET['lang_id'];
}

SE_Language::select($user);
if(SE_Language::info('language_setlocale') != '') { $multi_language = 1; setlocale(LC_TIME, SE_Language::info('language_setlocale')); }
header("Content-Language: ".SE_Language::info('language_code'));


// UPDATE STATS TABLE
update_stats("views");

// CREATE ACTIONS CLASS
$actions = new se_actions();

// CREATE NOTIFICATION CLASS
$notify = new se_notify();

// CREATE ADS CLASS
$ads = new se_ads();

// CREATE GLOBAL CSS STYLES VAR (USED FOR CUSTOM USER-DEFINED PROFILE/PLUGIN STYLES)
$global_css = "";




// INCLUDE RELEVANT PLUGIN FILES
// AND SET PLUGIN HEADER TEMPLATES
$show_menu_user = FALSE;
$global_plugins = Array();
$plugins = $database->database_query("SELECT plugin_type, plugin_icon FROM se_plugins WHERE plugin_disabled=0 ORDER BY plugin_id DESC");
while($plugin_info = $database->database_fetch_assoc($plugins)) { 
  $plugin_vars = Array();
  if(file_exists("header_".$plugin_info[plugin_type].".php")) { include "header_".$plugin_info[plugin_type].".php"; } 
  $global_plugins[$plugin_info[plugin_type]] = $plugin_vars;
  if($plugin_vars[menu_user] != "") { $show_menu_user = TRUE; }
}
$global_plugins[plugin_controls] = Array('show_menu_user' => $show_menu_user);






// CHECK TO SEE IF SITE IS ONLINE OR NOT
if($setting[setting_online] == 0) {
  // CREATE ADMIN OBJECT AND ATTEMPT TO LOG ADMIN IN
  $admin = new se_admin();
  $admin->admin_checkCookies();
  // ADMIN NOT LOGGED IN, DISPLAY OFFLINE PAGE
  if($admin->admin_exists == 0) {
    $page = "offline";
    include "footer.php";
  }
}


// CALL HEADER HOOK
($hook = SE_Hook::exists('se_header')) ? SE_Hook::call($hook, array()) : NULL;


// CHECK IF LOGGED-IN USER IS ON OWNER'S BLOCKLIST
if($user->user_exists == 1) {
  if($owner->user_blocked($user->user_info[user_id])) {
    // ASSIGN VARIABLES AND DISPLAY ERROR PAGE
    $page = "error";
    $smarty->assign('error_header', 639);
    $smarty->assign('error_message', 640);
    $smarty->assign('error_submit', 641);
    include "footer.php";
  }
}


// CHECK TO SEE IF USER HAS BEEN BLOCKED BY IP
$banned_ips = explode(",", $setting[setting_banned_ips]);
if(in_array($_SERVER['REMOTE_ADDR'], $banned_ips)) {
  // ASSIGN VARIABLES AND DISPLAY ERROR PAGE
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 807);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

?>