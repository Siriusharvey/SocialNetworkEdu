<html>
<form enctype="multipart/form-data"	action="<?print $_SERVER['PHP_SELF']?>" method ="post">
<div style="FONT-SIZE: 12px; COLOR: #333; FONT-FAMILY: Arial,sans-serif">Are you sure you want to delete this banner?</div><br />
<input type = "hidden" name = "delete">
<div align="right" style="padding-top:25px"><input type='button' name="no" class='button' value='No' onClick='parent.TB_remove();'>&nbsp;<input type = "submit" value = "Yes"></div>
</table>

<?php
$page = "del_banner";
include "header.php";
if($user->level_info[level_photo_allow] == 0) { header("Location: profile.php"); exit(); }

if ($user->user_exists != 0){
	if (isset ($_POST['delete'])){

		$target = "uploads_user/1000/".$user->user_info[user_id]."/"."banner_".$user->user_info[user_id].".jpg";
		chown($target,666);
		unlink($target);

  echo '&nbsp;<b>DONE</b>';

}
}

?>


</body>
</html>
