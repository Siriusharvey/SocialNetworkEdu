<html>
<form enctype="multipart/form-data"	action="upload_banner.php" method ="post">
<div style="FONT-SIZE: 12px; COLOR: #333; FONT-FAMILY: Arial,sans-serif"><br><b>You can upload ONLY JPG file.</b><br /><br>
<tr><td><input type = "hidden" name="MAX_FILE_SIZE" value = "51200"></td></tr>
<b>Select File:</b> <br><input type='file' name = "fupload">
<tr><td><input type = "submit" class="button" value = "Upload"></td></tr>
</div>
</table>


<?php
$page = "upload_banner";
include "header.php";
if($user->level_info[level_photo_allow] == 0) { header("Location: profile.php"); exit(); }

if ($user->user_exists != 0){
if (isset ($_FILES['fupload'])){


if ($_FILES['fupload']['type'] == "image/pjpeg" or $_FILES['fupload']['type'] == "image/jpeg"){
	$source = $_FILES['fupload']['tmp_name'];
	$target = "uploads_user/1000/".$user->user_info[user_id]."/"."banner_".$user->user_info[user_id].".jpg";
	
	move_uploaded_file($source, $target); // or die ("Couldnt copy");
	chmod($target, 0777);
	 echo '&nbsp;<b>DONE</b>';
	
  }
}
}

?>


</body>
</html>
