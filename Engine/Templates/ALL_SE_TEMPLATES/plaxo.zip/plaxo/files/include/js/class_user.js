
SocialEngineAPI.User = new Class({
  
  // Properties
  Base: {},
  
  user_exists : false,
  
  user_displayname : false,
  
  user_displayname_short : false,
  
  user_info : {},
  
  profile_info : {},
  
  level_info : {},
  
  usersetting_info : {},
  
  options : {
    'displayname_order' : 'standard'
  },
  
  
  
  // Methods
  initialize: function()
  {
    
  },
  
  
  userPhotoFullPath: function()
  {
    // No URL class
    if( !this.Base.URL )
      return false;
    
    // No user photo
    if( !this.user_info.user_photo )
      return this.Base.URL.url_base + 'images/nophoto.gif';
      
    return this.Base.URL.url_base + this.Base.URL.url_userdir(this.user_info.user_id) + this.user_info.user_photo;
  },
  
  
  
  
  
  // Import methods
  ImportUserInfo: function(user_info)
  {
    // Handle anonymous users
    if( !user_info || $type(user_info)!="object" || !user_info.user_exists )
    {
      this.user_exists = false;
      return;
    }
    
    this.user_exists = true;
    
    // Prepare data
    user_info.user_id = parseInt(user_info.user_id);
    delete user_info.user_exists;
    
    // Save user info
    this.user_info = user_info;
    
    // Generate display name
    this.user_info.user_fname = this.user_info.user_fname.trim();
    this.user_info.user_lname = this.user_info.user_lname.trim();
    
    if( this.user_info.user_fname && this.user_info.user_lname )
    {
      // Asian
      if( this.options.displayname_order=="asian" )
      {
        this.user_displayname_short = this.user_info.user_lname;
        this.user_displayname = this.user_info.user_lname + ' ' + this.user_info.user_fname;
      }
      
      // Standard
      else
      {
        this.user_displayname_short = this.user_info.user_fname;
        this.user_displayname = this.user_info.user_fname + ' ' + this.user_info.user_lname;
      }
    }
    
    else if( this.user_info.user_fname )
    {
      this.user_displayname = this.user_displayname_short = this.user_info.user_fname;
    }
    
    else if( this.user_info.user_lname )
    {
      this.user_displayname = this.user_displayname_short = this.user_info.user_lname;
    }
    
    else if( this.user_info.user_username )
    {
      this.user_displayname = this.user_displayname_short = this.user_info.user_username;
    }
  }
  
});