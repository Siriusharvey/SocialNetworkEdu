
var SocialEngineAPI = {

  version : '0.1.0alpha'

};



SocialEngineAPI.Base = new Class({

  // Methods
  initialize: function()
  {
    this.version = SocialEngineAPI.version;
  },
  
  
  
  RegisterModule: function(moduleObject)
  {
    moduleObject.Base = this;
  }

});