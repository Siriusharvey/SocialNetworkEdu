
SocialEngineAPI.Core = new Class({
  
  // Properties
  Base: {},
  
  settings: {},
  
  plugins: {},
  
  options : {
    ajaxURL : 'js_api.php'
  },

  
  
  
  // Methods
  initialize: function()
  {
    
  },

  
  
  
  // Import Methods
  ImportSettings: function(settings)
  {
    this.settings = settings;
  },

  
  
  
  // Import Methods
  ImportPlugins: function(plugins)
  {
    this.plugins = plugins;
  }
  
});