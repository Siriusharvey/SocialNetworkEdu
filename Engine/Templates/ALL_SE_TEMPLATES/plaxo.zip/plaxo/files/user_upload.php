<?php

// RETRIEVE SESSION ID/UPLOAD TOKEN
if(isset($_POST['session_id'])) { $session_id = $_POST['session_id']; } elseif(isset($_GET['session_id'])) { $session_id = $_GET['session_id']; } else { $session_id = NULL; }
if(isset($_POST['upload_token'])) { $upload_token = $_POST['upload_token']; } elseif(isset($_GET['upload_token'])) { $upload_token = $_GET['upload_token']; } else { $upload_token = NULL; }

// START SESSION
session_id($session_id);
session_start();

// CHECK VALIDITY OF SESSION
if($_SESSION['upload_token'] == $upload_token) {

  // SET NECESSARY COOKIES
  $_COOKIE['user_id'] = $_SESSION['ul_user_id'];
  $_COOKIE['user_email'] = $_SESSION['ul_user_email'];
  $_COOKIE['se_user_pass'] = $_SESSION['ul_user_password'];

  // INCLUDE NECESSARY FILE
  include $_SESSION['action'];

}

// BELOW SHOULD ONLY EXECUTE IF SOMEONE IS TRYING TO HIJACK A SESSION ID
$json = "{\"result\":\"failure\",\"error\":\"Invalid user session\",\"size\":\"\"}";
header('Content-type: application/json');
echo $json;
exit();
?>