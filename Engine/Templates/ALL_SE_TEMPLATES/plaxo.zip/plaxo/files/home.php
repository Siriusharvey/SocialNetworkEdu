<?php
$page = "home";
include "header.php";

if ($user->user_exists == 0){
header("Location: home2.php"); 
exit(); 	
}


// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 && $setting[setting_permission_portal] == 0) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 656);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}


// IF PREVIOUSLY LOGGED IN EMAIL COOKIE AVAILABLE, SET IT
if(isset($_COOKIE['prev_email'])) { $prev_email = $_COOKIE['prev_email']; } else { $prev_email = ""; }


// UPDATE REFERRING URLS TABLE
update_refurls();


// GET RECENT SIGNUPS
$signups_query = $database->database_query("SELECT user_id, user_username, user_fname, user_lname, user_photo FROM se_users WHERE user_verified='1' AND user_enabled='1' AND user_search='1' AND user_photo<>'' ORDER BY user_signupdate DESC LIMIT 20");
$signup_array = Array();
while($signup = $database->database_fetch_assoc($signups_query)) {

  $signup_user = new se_user();
  $signup_user->user_info[user_id] = $signup[user_id];
  $signup_user->user_info[user_username] = $signup[user_username];
  $signup_user->user_info[user_photo] = $signup[user_photo];
  $signup_user->user_info[user_fname] = $signup[user_fname];
  $signup_user->user_info[user_lname] = $signup[user_lname];
  $signup_user->user_displayname();

  $signup_array[] = $signup_user;
}



// GET RECENT POPULAR USERS (MOST FRIENDS)
$friends_query = $database->database_query("SELECT count(se_friends.friend_user_id2) AS num_friends, se_users.user_id, se_users.user_username, se_users.user_fname, se_users.user_lname, se_users.user_photo FROM se_friends LEFT JOIN se_users ON se_friends.friend_user_id1=se_users.user_id WHERE se_friends.friend_status='1' AND se_users.user_search='1' GROUP BY se_users.user_id ORDER BY num_friends DESC LIMIT 20");
$friend_array = Array();
while($friend = $database->database_fetch_assoc($friends_query)) {

  $friend_user = new se_user();
  $friend_user->user_info[user_id] = $friend[user_id];
  $friend_user->user_info[user_username] = $friend[user_username];
  $friend_user->user_info[user_photo] = $friend[user_photo];
  $friend_user->user_info[user_fname] = $friend[user_fname];
  $friend_user->user_info[user_lname] = $friend[user_lname];
  $friend_user->user_displayname();

  $friend_array[] = Array('friend' => $friend_user,
		       'total_friends' => $friend[num_friends]);
}




// GET RECENT LOGINS
$logins_query = $database->database_query("SELECT user_id, user_username, user_fname, user_lname, user_photo FROM se_users WHERE user_photo<>'' AND user_search='1' ORDER BY user_lastlogindate DESC LIMIT 20");
$login_array = Array();
while($login = $database->database_fetch_assoc($logins_query)) {

  $login_user = new se_user();
  $login_user->user_info[user_id] = $login[user_id];
  $login_user->user_info[user_username] = $login[user_username];
  $login_user->user_info[user_photo] = $login[user_photo];
  $login_user->user_info[user_fname] = $login[user_fname];
  $login_user->user_info[user_lname] = $login[user_lname];
  $login_user->user_displayname();

  $login_array[] = $login_user;
}



// GET NEWS ITEMS
$news = $database->database_query("SELECT * FROM se_announcements ORDER BY announcement_order DESC LIMIT 20");
$news_array = Array();
while($item = $database->database_fetch_assoc($news)) {

  // CONVERT SUBJECT/BODY BACK TO HTML
  $item['announcement_body'] = htmlspecialchars_decode($item['announcement_body'], ENT_QUOTES);
  $item['announcement_subject'] = htmlspecialchars_decode($item['announcement_subject'], ENT_QUOTES);
  $news_array[] = $item;

}


// GET TOTALS
$total_members = $database->database_fetch_assoc($database->database_query("SELECT count(*) AS total_members FROM se_users"));
$total_friends = $database->database_fetch_assoc($database->database_query("SELECT count(*) AS total_friends FROM se_friends WHERE friend_status='1'"));

// LOOP THROUGH COMMENT TABLES TO GET TOTAL COMMENTS
$total_comments = 0;
$comment_tables = $database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_%comments'");
while($table_info = $database->database_fetch_array($comment_tables)) {
  $comment_type = strrev(substr(strrev(substr($table_info[0], 3)), 8));
  $table_comments = $database->database_fetch_assoc($database->database_query("SELECT count(*) AS total_comments FROM se_".$comment_type."comments"));
  $total_comments += $table_comments[total_comments];
}

include "_percentage.php";
$profile_percent = show_percent($user->user_info[user_id]);



if (class_exists('se_blog')) {
	
//Blogs
if(isset($_POST['v'])) { $v = $_POST['v']; } elseif(isset($_GET['v'])) { $v = $_GET['v']; } else { $v = 0; }

// ENSURE SORT/VIEW ARE VALID
if($s != "blogentry_date DESC" && $s != "blogentry_views DESC" && $s != "total_comments DESC") { $s = "blogentry_date DESC"; }
if($v != "0" && $v != "1") { $v = 0; }

// SET WHERE CLAUSE
$where = "CASE
	    WHEN se_blogentries.blogentry_user_id='{$user->user_info[user_id]}'
	      THEN TRUE
	    WHEN ((se_blogentries.blogentry_privacy & @SE_PRIVACY_REGISTERED) AND '{$user->user_exists}'<>0)
	      THEN TRUE
	    WHEN ((se_blogentries.blogentry_privacy & @SE_PRIVACY_ANONYMOUS) AND '{$user->user_exists}'=0)
	      THEN TRUE
	    WHEN ((se_blogentries.blogentry_privacy & @SE_PRIVACY_FRIEND) AND (SELECT TRUE FROM se_friends WHERE friend_user_id1=se_blogentries.blogentry_user_id AND friend_user_id2='{$user->user_info[user_id]}' AND friend_status='1' LIMIT 1))
	      THEN TRUE
	    WHEN ((se_blogentries.blogentry_privacy & @SE_PRIVACY_SUBNET) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM se_users WHERE user_id=se_blogentries.blogentry_user_id AND user_subnet_id='{$user->user_info[user_subnet_id]}' LIMIT 1))
	      THEN TRUE
	    WHEN ((se_blogentries.blogentry_privacy & @SE_PRIVACY_FRIEND2) AND (SELECT TRUE FROM se_friends AS friends_primary LEFT JOIN se_users ON friends_primary.friend_user_id1=se_users.user_id LEFT JOIN se_friends AS friends_secondary ON friends_primary.friend_user_id2=friends_secondary.friend_user_id1 WHERE friends_primary.friend_user_id1=se_blogentries.blogentry_user_id AND friends_secondary.friend_user_id2='{$user->user_info[user_id]}' AND se_users.user_subnet_id='{$user->user_info[user_subnet_id]}' LIMIT 1))
	      THEN TRUE
	    ELSE FALSE
	END";


// ONLY MY FRIENDS' BLOGS
if( $v=="1" && $user->user_exists ){
  // SET WHERE CLAUSE
  $where .= " AND (SELECT TRUE FROM se_friends WHERE friend_user_id1={$user->user_info[user_id]} AND friend_user_id2=se_blogentries.blogentry_user_id AND friend_status=1)";
}
// CATEGORIES
if( isset($c) && $c!=-1 )
{
  if( $c==0 ) $c = '0';
  $where .= " AND blogentry_blogentrycat_id='$c'";
}
// SEARCH
if( !empty($blog_search) )
{
  $where .= " && MATCH (`blogentry_title`, `blogentry_body`) AGAINST ('{$blog_search}' IN BOOLEAN MODE)";
}
// CREATE blog OBJECT
$blog = new se_blog();

// GET TOTAL blogs
$total_blogentries = $blog->blog_entries_total($where);
// MAKE ENTRY PAGES
$blogentries_per_page = 3;
$page_vars = make_page($total_blogentries, $blogentries_per_page, $p);
// GET blog ARRAY
$blogentry_array = $blog->blog_entries_list($page_vars[0], $blogentries_per_page, $s, $where);
foreach( $blogentry_array as $blogentry_index=>$blogentry_item )
  $blogentry_array[$blogentry_index]['blogentry_body'] = cleanHTML($blogentry_item['blogentry_body'], '');
// GET BLOG ENTRY CATEGORIES
$blogentrycats_query = $database->database_query("SELECT * FROM se_blogentrycats ORDER BY blogentrycat_id ASC");
$blogentrycats_array = array();
while( $blogentrycat=$database->database_fetch_assoc($blogentrycats_query) )
{
  $blogentrycats_array[] = array(
    'blogentrycat_id' => $blogentrycat['blogentrycat_id'],
    'blogentrycat_title' => $blogentrycat['blogentrycat_title']
  );
}

$smarty->assign('total_blogentries', $total_blogentries);
$smarty->assign_by_ref('blogentries', $blogentry_array);
$smarty->assign_by_ref('blogentrycats', $blogentrycats_array);
$smarty->assign('blog_search', $blog_search);
$smarty->assign('v', $v);
}

// EVENTS
if (class_exists('se_event')) {
if(isset($_POST['s'])) { $s = $_POST['s']; } elseif(isset($_GET['s'])) { $s = $_GET['s']; } else { $s = "event_datecreated DESC"; }
if(isset($_POST['v'])) { $v = $_POST['v']; } elseif(isset($_GET['v'])) { $v = $_GET['v']; } else { $v = 0; }
if(isset($_POST['eventcat_id'])) { $eventcat_id = $_POST['eventcat_id']; } elseif(isset($_GET['eventcat_id'])) { $eventcat_id = $_GET['eventcat_id']; } else { $eventcat_id = 0; }

// ENSURE SORT/VIEW ARE VALID
if($s != "event_datecreated DESC" && $s != "num_members DESC" && $s != "event_date_start DESC" && $s != "event_date_end DESC" && $s != "event_date_start ASC" && $s != "event_date_end ASC") { $s = "event_date_start ASC"; }
if($v != "1" && $v != "2" && $v != "3") { $v = 3; }


// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if( (!$user->user_exists && !$setting['setting_permission_event']) || ($user->user_exists && (1 & ~$user->level_info['level_event_allow'])) )
{
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 656);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}


// SET WHERE CLAUSE
$where = "CASE
	    WHEN se_events.event_user_id='{$user->user_info[user_id]}'
	      THEN TRUE
	    WHEN ((se_events.event_privacy & 32) AND '{$user->user_exists}'<>0)
	      THEN TRUE
	    WHEN ((se_events.event_privacy & 64) AND '{$user->user_exists}'=0)
	      THEN TRUE
	    WHEN ((se_events.event_privacy & 2) AND (SELECT TRUE FROM se_eventmembers WHERE eventmember_user_id='{$user->user_info[user_id]}' AND eventmember_event_id=se_events.event_id AND eventmember_status=1 LIMIT 1))
	      THEN TRUE
	    WHEN ((se_events.event_privacy & 4) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM se_friends WHERE friend_user_id1=se_events.event_user_id AND friend_user_id2='{$user->user_info[user_id]}' AND friend_status=1 LIMIT 1))
	      THEN TRUE
	    WHEN ((se_events.event_privacy & 8) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM se_eventmembers LEFT JOIN se_friends ON se_eventmembers.eventmember_user_id=se_friends.friend_user_id1 WHERE se_eventmembers.eventmember_event_id=se_events.event_id AND se_friends.friend_user_id2='{$user->user_info[user_id]}' AND se_eventmembers.eventmember_status=1 AND se_friends.friend_status=1 LIMIT 1))
	      THEN TRUE
	    WHEN ((se_events.event_privacy & 16) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM se_eventmembers LEFT JOIN se_friends AS friends_primary ON se_eventmembers.eventmember_user_id=friends_primary.friend_user_id1 LEFT JOIN se_friends AS friends_secondary ON friends_primary.friend_user_id2=friends_secondary.friend_user_id1 WHERE se_eventmembers.eventmember_event_id=se_events.event_id AND se_eventmembers.eventmember_status=1 AND friends_secondary.friend_user_id2='{$user->user_info[user_id]}' AND friends_primary.friend_status=1 AND friends_secondary.friend_status=1 LIMIT 1))
	      THEN TRUE
	    ELSE FALSE
	END";


// ONLY MY FRIENDS' EVENTS
if( $v=="2" && $user->user_exists )
{
  // SET WHERE CLAUSE
  $where .= " AND (SELECT TRUE FROM se_friends LEFT JOIN se_eventmembers ON se_friends.friend_user_id2=se_eventmembers.eventmember_user_id WHERE friend_user_id1='{$user->user_info[user_id]}' AND friend_status=1 AND eventmember_event_id=se_events.event_id AND eventmember_status=1 LIMIT 1)";
}

elseif( $v=="3" )
{
  $where .= " && se_events.event_date_start>'".time()."' ";
  // Force sort?
  $s = "event_date_start ASC";
}

// CREATE EVENT OBJECT
$event = new se_event();

// GET TOTAL EVENTS
$total_events = $event->event_total($where);

// MAKE ENTRY PAGES
$events_per_page = 3;
$page_vars = make_page($total_events, $events_per_page, $p);

// GET EVENT ARRAY
$event_array = $event->event_list($page_vars[0], $events_per_page, $s, $where, TRUE);

// SET GLOBAL PAGE TITLE
$global_page_title[0] = 3000274; 
$global_page_description[0] = 3000275;


// ASSIGN SMARTY VARIABLES AND DISPLAY EVENTS PAGE

$smarty->assign('events', $event_array);
$smarty->assign('total_events', $total_events);
$smarty->assign('s', $s);
$smarty->assign('v', $v);
}


// ASSIGN SMARTY VARIABLES AND INCLUDE FOOTER
$smarty->assign('blogexists', class_exists('se_blog'));
$smarty->assign('eventexists', class_exists('se_event'));
$smarty->assign('prev_email', $prev_email);
$smarty->assign('signups', $signup_array);
$smarty->assign('friends', $friend_array);
$smarty->assign('logins', $login_array);
$smarty->assign('news', $news_array);
$smarty->assign('total_members', $total_members[total_members]);
$smarty->assign('total_friends', $total_friends[total_friends]);
$smarty->assign('total_comments', $total_comments);
$smarty->assign('ip', $_SERVER['REMOTE_ADDR']);
$smarty->assign('online_users', online_users());
$smarty->assign('actions', $actions->actions_display(0, $setting[setting_actions_actionsperuser]));
$smarty->assign('p_percent', $profile_percent);
$smarty->assign('page', $page);
include "footer.php";
?>