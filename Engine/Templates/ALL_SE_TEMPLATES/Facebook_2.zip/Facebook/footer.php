<?php

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// GET LANGUAGES AVAILABLE IF NECESSARY
if($setting[setting_lang_anonymous] == 1 || ($setting[setting_lang_allow] == 1 && $user->user_exists != 0)) {
  $lang_packlist = SE_Language::list_packs();
  ksort($lang_packlist);
  $lang_packlist = array_values($lang_packlist);
}


// ASSIGN LOGGED-IN USER VARS
if($user->user_exists != 0) { 
  $smarty->assign('user_unread_pms', $user->user_message_total(0, 1));
}


// CALL SPECIFIC PAGE HOOK
($hook = SE_Hook::exists('se_'.$page)) ? SE_Hook::call($hook, array()) : NULL;

// CALL FOOTER HOOK
($hook = SE_Hook::exists('se_footer')) ? SE_Hook::call($hook, array()) : NULL;

usort($database->query_stats, create_function('$a,$b', 'if($a[time] == $b[time]) { return 0; } else { return ($a[time] < $b[time]) ? -1 : 1; }'));

// CHECK IF IN SMOOTHBOX
$global_smoothbox = false;
if(isset($_GET['in_smoothbox'])) { if($_GET['in_smoothbox'] == true) { $global_smoothbox = true; }}

// ASSIGN GLOBAL SMARTY OBJECTS/VARIABLES AND DISPLAY PAGE
$smarty->assign_by_ref('url', $url);
$smarty->assign_by_ref('misc', $misc);
$smarty->assign_by_ref('datetime', $datetime);
$smarty->assign_by_ref('database', $database);
$smarty->assign_by_ref('user', $user);
$smarty->assign_by_ref('owner', $owner);
$smarty->assign_by_ref('ads', $ads);
$smarty->assign_by_ref('setting', $setting);
$smarty->assign_by_ref('se_javascript', $se_javascript);
$smarty->assign('lang_packlist', $lang_packlist);
$smarty->assign('notifys', $notify->notify_summary());
$smarty->assign('global_plugins', $global_plugins);
$smarty->assign('global_smoothbox', $global_smoothbox);
$smarty->assign('global_page', $page);
$smarty->assign('global_page_title', $global_page_title);
$smarty->assign('global_page_description', str_replace("\"", "'", $global_page_description));
$smarty->assign('global_css', $global_css);
$smarty->assign('global_timezone', $global_timezone);
$smarty->assign('global_language', SE_Language::info('language_id'));
$smarty->display("$page.tpl");
$smarty->assign('actions', $actions->actions_display($setting[setting_actions_visibility], $setting[setting_actions_actionsperuser]));
$smarty->assign('actiontypes', $actiontypes_array);
exit();
?>