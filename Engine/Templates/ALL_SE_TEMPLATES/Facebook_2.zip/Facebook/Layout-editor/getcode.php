<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<title>Profile Generator</title>

	<link rel="stylesheet" href="css/application.css" type="text/css" media="all" />
</head>

<body>



  <div id="application">
    <div id="window">
      <div class="innerwrap"> <div class="content">
        <h1>Congratulations, your layout is complete!</h1>
        <strong>How to Install:</strong>
        <ol>
          <li>Login to your MySpace Account</li>
          <li>Click the "Edit My Profile" link on the right side of your profile
            picture</li>

          <li>Click the "(edit)" link next to the box titled "About Me"</li>
          <li>Copy (CTR+C) the code below and paste (CTR+V) it into the "About
            Me" box, then click the "Preview" button</li>
          <li>Next, click the "Submit" button</li>
          <li>Click the "View My Profile" link near the top of the page, and that
            it's! Your new layout is installed!</li>
        </ol>
        <p><strong>Important Note:</strong> If you have another layout installed
          on your page, remove it before adding your new layout code.</p>

        <strong>Layout Code:</strong><br />
        <textarea id="codebox" name="codebox" class="codebox" cols="40" rows="20" onFocus="this.select()" onClick="this.select()" readonly>

&lt;style type="text/css">
body {
	background-color: <?=$_POST['in_backgroundColor'];?>;
	background-image: url(<?=$_POST['s_bgiu'];?>);
	background-position: <?=$_POST['in_backgroundPosition'];?>;
	background-repeat: <?=$_POST['in_backgroundRepeat'];?>;
	background-attachment: <?=$_POST['in_backgroundAttachment'];?>;
	}
table, tr, td {
	background-color: <?=$_POST['in_sectionBackgroundColor'];?>;
	border: <?=$_POST['in_sectionBorderWidth'];?>px;
	}

table table {
	border: <?=$_POST['in_sectionBorderWidth'];?>px;
	}
table table table table{
	border: <?=$_POST['in_sectionBorderWidth'];?>px;
	}
table table table {
	border-width: <?=$_POST['in_sectionBorderWidth'];?>px;
	border-color: <?=$_POST['in_sectionBorderColor'];?>;
	border-style: <?=$_POST['in_sectionBorderStyle'];?>;
	background-color: <?=$_POST['in_sectionBackgroundColor'];?>;
	}
table table table td {
	background-color: <?=$_POST['in_sectionBackgroundColor'];?>;
	filter:alpha(<?=$_POST['in_sectionOpacity'];?>);
	-moz-opacity:0.;
	opacity: <?=$_POST['in_sectionOpacity'];?>;
	-khtml-opacity:0.;
	}
table table table table td {
	filter:none;
body, div, span, td, p, .orangetext15, .whitetext12, .lightbluetext8, strong, b, u, .redtext, .redbtext, .btext, .text, .nametext, .blacktext10, .blacktext12 {
	font-family: <?=$_POST['in_headingFontFamily'];?>;
	font-size: <?=$_POST['in_fontSize'];?>px;
	color: <?=$_POST['in_headingFontColor'];?>;
	font-weight: <?=$_POST['in_headingFontWeight'];?>;
	font-style: <?=$_POST['in_headingFontStyle'];?>;
	text-decoration: <?=$_POST['in_headingFontDecoration'];?>;
	}
.nametext {
	padding: 5px;
	font-family: <?=$_POST['in_nameFontFamily'];?>;
	font-size: <?=$_POST['in_nameFontSize'];?>px;
	color: <?=$_POST['in_nameFontColor'];?>;
	font-weight: <?=$_POST['in_nameFontWeight'];?>;
	font-style: <?=$_POST['in_nameFontStyle'];?>;
	text-decoration: <?=$_POST['in_nameFontDecoration'];?>;
	display: block;
	}
.whitetext12, .orangetext15 {
	font-family: <?=$_POST['in_fontFamily'];?>;
	font-size: <?=$_POST['in_fontSize'];?>px;
	color: <?=$_POST['in_fontColor'];?>;
	font-weight: <?=$_POST['in_fontWeight'];?>;
	font-style: <?=$_POST['in_fontStyle'];?>;
	text-decoration: <?=$_POST['in_fontDecoration'];?>;
	}
a.navbar:link, a.navbar:active, a.navbar:visited, a.navbar:hover, a.man:link, a.man:active, a.man:visited, a.man:hover, a, a:link, a:active, a:visited, a:hover, a.navbar:link, a.navbar:active, a.navbar:visited, a.navbar:hover, a.text:link, a.text:active, a.text:visited, a.text:hover, a.searchlinksmall:link, a.searchlinksmall:active, a.searchlinksmall:visited, a.searchlinksmall:hover, a.redlink:link, a.redlink:active, a.redlink:visited, a.redlink:hover {
	color: in_linkFontColor;
	font-weight: in_linkFontWeight;
	font-style: in_linkFontStyle;
	text-decoration: in_linkFontDecoration;
	}
a.navbar:hover, a.man:hover, a:hover {
	color: in_linkHoverFontColor;
	font-weight: in_linkHoverFontWeight;
	font-style: in_linkHoverFontStyle;
	text-decoration: in_linkHoverFontDecoration;
	}
.badge {
	position: absolute;
	left: 1px;
	top: 1px;
	}

&lt;/style>
&lt;a href="http://www.yourwebsite.com/" target="_blank">&lt;img src="http://www.yourwebsite.com/images/support.gif" alt="MySpace Generators" style="position:absolute; left:0px; top: 0px;" border="0">This profile was made at www.yourcompany.com&lt;/a> 



</textarea></div></div></body></html>
