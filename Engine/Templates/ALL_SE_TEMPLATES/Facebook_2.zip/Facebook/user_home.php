<?php
$page = "user_home";
include "header.php";

if(isset($_GET['task'])) { $task = $_GET['task']; } elseif(isset($_POST['task'])) { $task = $_POST['task']; } else { $task = "main"; }

// RESET PROFILE VIEWS
if($task == "resetviews") {
  $database->database_query("UPDATE se_profileviews SET profileview_views=0, profileview_viewers='' WHERE profileview_user_id='".$user->user_info[user_id]."' LIMIT 1");
}


// POPULATE USER SETTINGS ARRAY
$user->user_settings();

// GET NEWS ITEMS
$news = $database->database_query("SELECT * FROM se_announcements ORDER BY announcement_order DESC LIMIT 20");
$news_array = Array();
while($item = $database->database_fetch_assoc($news)) {

  // CONVERT SUBJECT/BODY BACK TO HTML
  $item['announcement_body'] = htmlspecialchars_decode($item['announcement_body'], ENT_QUOTES);
  $item['announcement_subject'] = htmlspecialchars_decode($item['announcement_subject'], ENT_QUOTES);
  $news_array[] = $item;

}


// RETRIEVE VIEWS AND VIEWERS IF NECESSARY
$profile_views = 0;
$profile_viewers = Array();
$view_query = $database->database_query("SELECT profileview_views, profileview_viewers FROM se_profileviews WHERE profileview_user_id='".$user->user_info[user_id]."'");
if($database->database_num_rows($view_query) == 1) {
  $views = $database->database_fetch_assoc($view_query);
  $profile_views = $views[profileview_views];
  if($views[profileview_viewers] == "") { $views[profileview_viewers] = "''"; }
  $viewer_query = $database->database_query("SELECT user_id, user_username, user_fname, user_lname FROM se_users WHERE user_id IN ($views[profileview_viewers])");
  while($viewer_info = $database->database_fetch_assoc($viewer_query)) {
    $viewer = new se_user();
    $viewer->user_info[user_id] = $viewer_info[user_id];
    $viewer->user_info[user_username] = $viewer_info[user_username];
    $viewer->user_info[user_fname] = $viewer_info[user_fname];
    $viewer->user_info[user_lname] = $viewer_info[user_lname];
    $viewer->user_displayname();

    // SET PROFILE VIEWERS 
    $profile_viewers[] = $viewer;
  }
  $profile_viewers_array = explode(",", $views[profileview_viewers]);
  usort($profile_viewers, create_function('$a,$b', 'global $profile_viewers_array; if(array_search($a->user_info[user_id], $profile_viewers_array) == array_search($b->user_info[user_id], $profile_viewers_array)) { return 0; } else { return (array_search($a->user_info[user_id], $profile_viewers_array) < array_search($b->user_info[user_id], $profile_viewers_array)) ? -1 : 1; }'));
}


// CREATE ARRAY OF ACTION TYPES
if($setting[setting_actions_preference] == 1) {

  // GET ACTION TYPES
  $actiontypes_display = explode(",", $user->usersetting_info[usersetting_actions_display]);
  $actiontypes_query = $database->database_query("SELECT * FROM se_actiontypes WHERE actiontype_enabled=1");
  while($actiontype = $database->database_fetch_assoc($actiontypes_query)) {

    // MAKE THIS ACTION TYPE SELECTED IF ITS NOT DISALLOWED BY USER
    $actiontype_selected = 0;
    if(in_array($actiontype[actiontype_id], $actiontypes_display)) { $actiontype_selected = 1; }
    SE_Language::_preload($actiontype[actiontype_desc]);
    $actiontypes_array[] = Array('actiontype_id' => $actiontype[actiontype_id],
			       'actiontype_selected' => $actiontype_selected,
			       'actiontype_desc' => $actiontype[actiontype_desc]);
  }
}


// GET UPCOMING BIRTHDAYS, START BY CHECKING FOR BIRTHDAY PROFILE FIELDS
$birthday_array = Array();
$birthday_fields = $database->database_query("SELECT profilefield_id, t2.profilecat_id FROM se_profilefields LEFT JOIN se_profilecats AS t1 ON se_profilefields.profilefield_profilecat_id=t1.profilecat_id LEFT JOIN se_profilecats AS t2 ON t1.profilecat_dependency=t2.profilecat_id WHERE profilefield_special='1'");
if($database->database_num_rows($birthday_fields) > 0) {

  // CONSTRUCT QUERY
  $birthdays_upcoming_query = "SELECT se_users.user_id, 
					se_users.user_username, 
					se_users.user_fname, 
					se_users.user_lname,
					CASE ";
  while($birthday_field = $database->database_fetch_assoc($birthday_fields)) {
    $birthdays_upcoming_query .= " WHEN se_users.user_profilecat_id=$birthday_field[profilecat_id] THEN DATE_FORMAT(CONCAT(YEAR(CURDATE()), \"-\", MONTH(se_profilevalues.profilevalue_$birthday_field[profilefield_id]), \"-\", DAY(se_profilevalues.profilevalue_$birthday_field[profilefield_id])), '%Y-%m-%d')";
    $birthdays_upcoming_where[] = "(se_users.user_profilecat_id=$birthday_field[profilecat_id] AND DAY(se_profilevalues.profilevalue_$birthday_field[profilefield_id])<>'0' AND MONTH(se_profilevalues.profilevalue_$birthday_field[profilefield_id])<>'0' AND CURDATE() <= DATE_FORMAT(CONCAT(YEAR(CURDATE()), \"-\", MONTH(se_profilevalues.profilevalue_$birthday_field[profilefield_id]), \"-\", DAY(se_profilevalues.profilevalue_$birthday_field[profilefield_id])), '%Y-%m-%d') AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) >= DATE_FORMAT(CONCAT(YEAR(CURDATE()), \"-\", MONTH(se_profilevalues.profilevalue_$birthday_field[profilefield_id]), \"-\", DAY(se_profilevalues.profilevalue_$birthday_field[profilefield_id])), '%Y-%m-%d'))";
  }
  $birthdays_upcoming_query .= " ELSE '0000-00-00' END AS birthday FROM se_friends LEFT JOIN se_users ON se_friends.friend_user_id2=se_users.user_id LEFT JOIN se_profilevalues ON se_users.user_id=se_profilevalues.profilevalue_user_id WHERE se_friends.friend_user_id1=".$user->user_info[user_id]." AND (".implode(" OR ", $birthdays_upcoming_where).") ORDER BY birthday";

  $birthdays = $database->database_query($birthdays_upcoming_query);
  while($birthday = $database->database_fetch_assoc($birthdays)) {
    $fullname = $birthday[user_fname].((trim($birthday[user_fname]) != "" && trim($birthday[user_lname]) != "") ? " " : "").$birthday[user_lname];
    $user_displayname_short = (trim($birthday[user_fname]) != "") ? $birthday[user_fname] : $birthday[user_username];
    $user_displayname = (trim($fullname) != "") ? $fullname : $birthday[user_username];

    // SET BIRTHDAY
    $birthday_date = mktime(0, 0, 0, substr($birthday[birthday], 5, 2), substr($birthday[birthday], 8, 2), 1990);

    $birthday_array[] = Array('birthday_user_id' => $birthday[profilevalue_user_id],
			    'birthday_user_username' => $birthday[user_username],
			    'birthday_user_displayname' => $user_displayname,
			    'birthday_date' => $birthday_date);
  }
}





//FRIENDS OF FRIENDS PLUGIN 
include('right_side_fof.php');


// GET RECENT STATUS UPDATES
$statuses = $database->database_query("SELECT user_id, user_username, user_photo, user_fname, user_lname, user_status FROM se_users WHERE user_subnet_id='$n' AND user_photo<>'' AND user_id<>".$user->user_info[user_id]." AND user_status<>'' ORDER BY user_status_date DESC LIMIT 10");
while($status = $database->database_fetch_assoc($statuses)) {
  $status_user = new se_user();
  $status_user->user_info[user_id] = $status[user_id];
  $status_user->user_info[user_username] = $status[user_username];
  $status_user->user_info[user_photo] = $status[user_photo];
  $status_user->user_info[user_fname] = $status[user_fname];
  $status_user->user_info[user_lname] = $status[user_lname];
  $status_user->user_info[user_status] = $status[user_status];
  $status_user->user_displayname();

  $statuses_array[] = $status_user;

}

// ASSIGN SMARTY VARS AND INCLUDE FOOTER
$smarty->assign('profile_views', $profile_views);
$smarty->assign('profile_viewers', $profile_viewers);
$smarty->assign('total_friend_requests', $user->user_friend_total(1, 0));
$smarty->assign('news', $news_array);
$smarty->assign('actions', $actions->actions_display($setting[setting_actions_visibility], $setting[setting_actions_actionsperuser]));
$smarty->assign('online_users', online_users());
$smarty->assign('actiontypes', $actiontypes_array);
$smarty->assign('birthdays', $birthday_array);
$smarty->assign('statuses', $statuses_array);
include "footer.php";
?>