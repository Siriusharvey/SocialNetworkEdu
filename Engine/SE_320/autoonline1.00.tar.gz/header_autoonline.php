<?php

if(!defined('SE_PAGE')) { exit(); }

include "./include/functions_autoonline.php";

$autoonline_settings = get_autoonline_settings();

if(isset($autoonline_settings['enabled']) && (int)$autoonline_settings['enabled'] && (($autoonline_settings['lastactive'] < time()-5*60) || (int)$autoonline_settings['lastactive'] == 0))
{
set_online_users((int)$autoonline_settings['percent_online'], 
						$autoonline_settings['pass_pg'], 
							$autoonline_settings['with_pic'],
								$autoonline_settings['online_time'],
									$autoonline_settings['update_photo']);
}


?>