<?php

function get_autoonline_settings()
{
	global $database;
	
	$sql = "
		SELECT *
		FROM `se_autoonline_settings`";
	return $database->database_fetch_assoc($database->database_query($sql));
}

function get_autoonline_total($profilegen_pass,$with_pic)
{
	global $database;
	$pass = '';
	$photo = '';
	if ($with_pic == 1) $photo=" AND se_users.user_photo != ''";
	if ($profilegen_pass != '') $pass = " AND se_users.user_password = '".md5($profilegen_pass)."'";
	$sql = "SELECT se_users.user_id FROM se_users WHERE se_users.user_verified='1' AND se_users.user_enabled='1' ".$pass." ".$photo."";
	return $database->database_num_rows($database->database_query($sql));
}

function get_autoonline_onlinenow()
{
	global $database;
	
	$sql = "
		SELECT se_visitors.visitor_user_id 
		FROM `se_visitors` 
		WHERE se_visitors.visitor_user_id != '0' 
		AND se_visitors.visitor_invisible=0
    	AND se_visitors.visitor_ip = '".ip2long('10.168.0.255')."'";
	return $database->database_num_rows($database->database_query($sql));
}

function set_online_users($percent,$profilegen_pass,$with_pic,$online_time,$update_photo)
{
	global $database;
	$total_users = get_autoonline_total($profilegen_pass,$with_pic);
	$photo = "";
	if ($with_pic == 1) $photo=" AND se_users.user_photo != ''";

	$sql = "
		DELETE FROM `se_visitors` 
		WHERE se_visitors.visitor_user_id != '0' 
		AND se_visitors.start_online < '".(time()-($online_time*60))."' AND se_visitors.visitor_invisible=0
    	AND se_visitors.visitor_ip = '".ip2long('10.168.0.255')."'";
	$database->database_query($sql);//delete else start_online < online_time

		// UPDATE USER LAST ACTIVE se_visitors
    $sql = "UPDATE `se_visitors` SET visitor_lastactive='".time()."' 
			WHERE visitor_user_id !='0' 
			AND se_visitors.visitor_ip = '".ip2long('10.168.0.255')."' AND se_visitors.visitor_invisible=0
			AND se_visitors.start_online > '".(time()-($online_time*60))."'";
    $database->database_query($sql);
	// UPDATE USER LAST ACTIVE se_users
	
	$online_profile_gen = get_autoonline_onlinenow();	
	if ($online_profile_gen == 0) 
	{
	$rand_percent = rand($percent,$percent+10);
	$limit = floor($total_users*$rand_percent/100);
	$pass="";
	if ($profilegen_pass != '') $pass = " AND se_users.user_password = '".md5($profilegen_pass)."'";
	$sql = "SELECT se_users.user_id, se_users.user_username, se_users.user_displayname FROM se_users WHERE se_users.user_verified='1' AND se_users.user_enabled='1' ".$pass." ".$photo." ORDER BY RAND() LIMIT ".$limit."";
	
  $users = $database->database_query($sql);
  while($user_info = $database->database_fetch_assoc($users))
  {
    $user_id[] = $user_info['user_id'];
	$user_username[] = $user_info['user_username'];
	$user_displayname[] = $user_info['user_displayname'];
  }	

	$count_online=count($user_id);

	//UPDATE PROFILE PHOTO (default 5-10%)
	if ($with_pic == 1 && $update_photo == 1) {
	$percent_update_photo = rand(5,10);
	$limit_update_photo = $limit * $percent_update_photo/100;
	}
	for($i=0; $i < $count_online; $i++) {//add members
      $visitor_ip = ip2long('10.168.0.255');
      $visitor_browser = "Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.0.13) Gecko/2009073022 Firefox/3.0.13";
      $visitor_lastactive = time();//-rand(1,30)
      $visitor_invisible = 0;
      
      $visitor_user_id = $user_id[$i];
      $visitor_user_username = $user_username[$i];
      $visitor_user_displayname = $user_displayname[$i];
      
	  $start_online = $visitor_lastactive;
      $sql = "
        INSERT INTO `se_visitors` (
          visitor_ip,
          visitor_browser,
          visitor_lastactive,
          visitor_invisible,
          visitor_user_id,
          visitor_user_username,
          visitor_user_displayname,
		  start_online
        ) VALUES (
          '$visitor_ip',
          '$visitor_browser',
          '$visitor_lastactive',
          '$visitor_invisible',
          '$visitor_user_id',
          '$visitor_user_username', 
          '$visitor_user_displayname',
		  '$start_online'
        )";
	  $database->database_query($sql);
      
	  // UPDATE USER LAST ACTIVE IF LOGGED IN
      $sql = "UPDATE se_users SET user_lastactive='$visitor_lastactive', user_lastlogindate='$visitor_lastactive' WHERE user_id='$visitor_user_id' LIMIT 1";//, user_dateupdated='$visitor_lastactive'
      $database->database_query($sql);
	  /** Update Edit Photo Date**/
	  if ($limit_update_photo > 0) {
	  $sql = 'UPDATE `se_actions` SET `action_date` = '. ($visitor_lastactive-rand(1,60)) .' WHERE `action_user_id` = '. $visitor_user_id .' AND `action_actiontype_id` = (SELECT `actiontype_id` FROM `se_actiontypes` WHERE `actiontype_name` = "editphoto" LIMIT 1)';
      $database->database_query( $sql );
	  $limit_update_photo--;
	  }
	}
}
			$sql = "
				UPDATE `se_autoonline_settings`
				SET `lastactive` = '".time()."' WHERE `id` = '1'";//".time()."
			$database->database_query($sql);
}
?>