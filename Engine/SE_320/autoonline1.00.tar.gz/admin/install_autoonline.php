<?php
define("DELETE_TABLES_BEFORE_CREATE", false);

$plugin_name = 'Autoonline';
$plugin_version = '1.00';
$plugin_type = 'autoonline';
$plugin_desc = 'This plug allows you to simulate activity on your site. It puts members to online status thus if someone come to your site.';
$plugin_icon = 'admin_autoonline16.gif';
$plugin_pages_main = '9000701<!>admin_autoonline16.gif<!>admin_autoonline.php<~!~>';
$plugin_pages_level = '';
$plugin_url_htaccess = '';

/**

/images/icons/admin_autoonline16.gif

**/

if ( $install == 'autoonline' ) {
$query = "INSERT INTO se_plugins (plugin_name, plugin_version, plugin_type, plugin_desc, plugin_icon, plugin_pages_main, plugin_pages_level, plugin_url_htaccess) VALUES ('$plugin_name', '$plugin_version', '$plugin_type', '$plugin_desc', '$plugin_icon', '$plugin_pages_main', '$plugin_pages_level', '$plugin_url_htaccess')";
$query_update = "UPDATE se_plugins SET plugin_name='$plugin_name', plugin_version='$plugin_version', plugin_desc='$plugin_desc', plugin_icon='$plugin_icon', plugin_pages_main='$plugin_pages_main', plugin_pages_level='$plugin_pages_level', plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'";

	if ( $database->database_num_rows( $database->database_query( "SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'" ) ) == 0 )
	
		$database->database_query( $query );
	else
		$database->database_query( $query_update );

	if ( $database->database_num_rows( $database->database_query( "SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 9000701 LIMIT 1" ) ) == 0 ) 
		$database->database_query( "INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES 
					(9000701, 1, 'Autoonline members', 'admin_header,'),
					(9000702, 1, 'This plug allows you to simulate activity on your site. It puts members to online status thus if someone come to your site he\'ll see that there are a number of online members.', 'admin_title,'),
					(9000703, 1, 'General Autoonline settings', 'admin_title,'),
					(9000704, 1, 'Autoonline Enabled', 'admin_title,'),
					(9000705, 1, 'Save Settings', 'admin_title,'),
					(9000706, 1, 'Your general autoonline settings have been saved', 'admin_success,'),
					(9000707, 1, 'Percent online', 'admin_title,'),
					(9000708, 1, 'Updated profile photo (What\'s New ?)', 'admin_title,'),
					(9000709, 1, 'Total profiles', 'admin_title,'),
					(9000710, 1, 'Online now', 'admin_title,'),
					(9000711, 1, 'Online time', 'admin_title,'),
					(9000712, 1, 'With pictures only', 'admin_title,'),
					(9000713, 1, 'Profile password', 'admin_title,')" );
create_tables();
}

function create_table($table_name, $query)
{
	global $database, $database_name;
	
	$sql = "
		SHOW TABLES
		FROM `".$database_name."`
		LIKE '".$table_name."'";
	if(DELETE_TABLES_BEFORE_CREATE)
	{
		$database->database_query("DROP TABLE IF EXISTS `".$table_name."`");
		$database->database_query($query);
	}
	else if($database->database_num_rows($database->database_query($sql)) == 0)
		$database->database_query($query);
	
	return true;
}
function create_tables()
{
	global $database;
	$table_name = "se_autoonline_settings";
	$query = "
		CREATE TABLE `".$table_name."` (
  `id` int(11) NOT NULL auto_increment,
  `enabled` tinyint(1) NOT NULL default '0',
  `percent_online` int(11) default '10',
  `lastactive` int(14) default '0',
  `online_time` int(14) default '15',
  `pass_pg` varchar(50) collate utf8_unicode_ci default 'password',
  `with_pic` tinyint(1) default '0',
  `update_photo` tinyint(1) default '0',
		PRIMARY KEY  (`id`)
		) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_unicode_ci";
	create_table($table_name, $query);
	$query = "ALTER TABLE `se_visitors` ADD `start_online` INT( 14 ) DEFAULT '0' NOT NULL";
	$database->database_query($query);		
	return true;
}
?>