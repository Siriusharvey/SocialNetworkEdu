<?php

if ( !defined( 'SE_PAGE' ) ) { exit(); }
include "../include/functions_autoonline.php";
?>