<?php

$page = "admin_autoonline";
include "admin_header.php";

$task = "";
$iSuccess=0;
if(isset($_REQUEST['task']) && $_REQUEST['task'])
	$task = $_REQUEST['task'];

$members_online = get_autoonline_onlinenow();
$autoonline_settings = get_autoonline_settings();
$total_users = get_autoonline_total($autoonline_settings['pass_pg'],$autoonline_settings['with_pic']);

$autoonline_enabled = (isset($autoonline_settings['enabled']) && $autoonline_settings['enabled'] ? true : false);
$percent_online = (isset($autoonline_settings['percent_online']) && $autoonline_settings['percent_online'] ? (int)$autoonline_settings['percent_online'] : 10);
$online_time  = (isset($autoonline_settings['online_time']) && $autoonline_settings['online_time'] ? (int)$autoonline_settings['online_time'] : 15);
$pass_profile_generator = isset($autoonline_settings['pass_pg']) && $autoonline_settings['pass_pg'] ? addslashes($autoonline_settings['pass_pg']) : '';
$with_pic  = (isset($autoonline_settings['with_pic']) && $autoonline_settings['with_pic'] ? (int)$autoonline_settings['with_pic'] : 0);
$update_photo  = (isset($autoonline_settings['update_photo']) && $autoonline_settings['update_photo'] ? (int)$autoonline_settings['update_photo'] : 0);

if ($task == 'autoonline_settings')
{
		$autoonline_enabled = isset($_POST['autoonline_enabled']) && $_POST['autoonline_enabled'] ? $_POST['autoonline_enabled'] : 0;
		$percent_online = isset($_POST['user_percent']) && $_POST['user_percent'] ? (int)$_POST['user_percent'] : 10;
		$online_time = (isset($_POST['user_online']) && $_POST['user_online'] ? (int)$_POST['user_online'] : 15);
		$pass_profile_generator = isset($_POST['password']) && $_POST['password'] ? addslashes($_POST['password']) : '';
		$with_pic = (isset($_POST['with_pictures']) && $_POST['with_pictures'] ? (int)$_POST['with_pictures'] : 0);
		$update_photo = (isset($_POST['update_photo']) && $_POST['update_photo'] ? (int)$_POST['update_photo'] : 0);

			$sql = "
				REPLACE INTO `se_autoonline_settings`
				SET 
					`id` = 1,
					`enabled` = '".$autoonline_enabled."',
					`percent_online` = '".$percent_online."',
					`online_time` = '".$online_time."',
					`pass_pg` = '".$pass_profile_generator."',
					`with_pic` = '".$with_pic."',
					`update_photo` = '".$update_photo."'";
			$database->database_query($sql);
			$sql = "
				DELETE FROM `se_visitors` 
				WHERE se_visitors.visitor_user_id != '0' 
				AND se_visitors.visitor_invisible=0
		    	AND se_visitors.visitor_ip = '".ip2long('10.168.0.255')."'";
			$database->database_query($sql);//delete else start_online < online_time			
			$iSuccess=9000706;
}

$smarty->assign( 'autoonline_enabled', $autoonline_enabled);
$smarty->assign( 'is_success', $iSuccess );
$smarty->assign( 'user_percent', $percent_online );
$smarty->assign( 'user_online', $online_time );
$smarty->assign( 'total_users', $total_users );
$smarty->assign( 'members_online', $members_online );
$smarty->assign( 'password', $pass_profile_generator );
$smarty->assign( 'with_pictures', $with_pic );
$smarty->assign( 'update_photo', $update_photo );

include "admin_footer.php";
?>