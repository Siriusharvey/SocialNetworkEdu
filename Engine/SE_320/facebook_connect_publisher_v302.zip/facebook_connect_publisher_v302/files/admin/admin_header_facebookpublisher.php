<?php

defined('SE_PAGE') or exit();

if( defined('SEMODS_HEADER_OPENIDCONNECT') ) return;

include_once "admin_header_openidconnect.php";

?>