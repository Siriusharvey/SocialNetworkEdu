<?php

// INCLUDE CLASS FILE
include_once "../include/class_openidconnect_facebook.php";

// INCLUDE FUNCTION FILE
include_once "../include/functions_openidconnect_facebook.php";


?>