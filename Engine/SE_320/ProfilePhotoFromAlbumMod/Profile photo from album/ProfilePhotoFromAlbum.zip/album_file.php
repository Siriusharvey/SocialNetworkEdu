<?php

/* $Id: album_file.php 2 2009-01-10 20:53:09Z john $ */

$page = "album_file";
include "header.php";


// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if( !$user->user_exists && !$setting['setting_permission_album'] )
{
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 656);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// DISPLAY ERROR PAGE IF NO OWNER
if( !$owner->user_exists )
{
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 828);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// ENSURE ALBUMS ARE ENABLED FOR THIS USER
if( !$owner->level_info['level_album_allow'] )
{
  header("Location: ".$url->url_create('profile', $owner->user_info[user_username]));
  exit();
}


// PARSE GET/POST
if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_POST['media_id'])) { $media_id = $_POST['media_id']; } elseif(isset($_GET['media_id'])) { $media_id = $_GET['media_id']; } else { $media_id = 0; }
if(isset($_POST['album_id'])) { $album_id = $_POST['album_id']; } elseif(isset($_GET['album_id'])) { $album_id = $_GET['album_id']; } else { $album_id = ""; }

// MAKE SURE MEDIA EXISTS
$media_query = $database->database_query("SELECT * FROM se_media WHERE media_id='$media_id' LIMIT 1");
if($database->database_num_rows($media_query) != 1) { header("Location: ".$url->url_create('albums', $owner->user_info[user_username])); exit(); }
$media_info = $database->database_fetch_assoc($media_query);


// BE SURE ALBUM BELONGS TO THIS USER
$album = $database->database_query("SELECT * FROM se_albums WHERE album_id='$media_info[media_album_id]' AND album_user_id='".$owner->user_info[user_id]."'");
if($database->database_num_rows($album) != 1) { header("Location: ".$url->url_create('albums', $owner->user_info[user_username])); exit(); }
$album_info = $database->database_fetch_assoc($album);

// CHECK PRIVACY
$privacy_max = $owner->user_privacy_max($user);
if(!($album_info[album_privacy] & $privacy_max)) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 1000125);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// GET CUSTOM ALBUM STYLE IF ALLOWED
if($owner->level_info[level_album_style] != 0) {
  $albumstyle_info = $database->database_fetch_assoc($database->database_query("SELECT albumstyle_css FROM se_albumstyles WHERE albumstyle_user_id='".$owner->user_info[user_id]."' LIMIT 1"));
  $global_css = $albumstyle_info[albumstyle_css];
}

// GET MEDIA IN ALBUM FOR CAROUSEL
$media_array = Array();
$media_query = $database->database_query("SELECT media_id, media_ext, '{$owner->user_info[user_id]}' AS album_user_id FROM se_media WHERE media_album_id='$album_info[album_id]' ORDER BY media_order ASC");
while($thismedia = $database->database_fetch_assoc($media_query)) { $media_array[$thismedia[media_id]] = $thismedia; }




// GET MEDIA WIDTH/HEIGHT
$mediasize = @getimagesize($url->url_userdir($owner->user_info[user_id]).$media_info[media_id].'.'.$media_info[media_ext]);
$media_info[media_width] = $mediasize[0];
$media_info[media_height] = $mediasize[1];


// GET ALBUM TAG PRIVACY
$allowed_to_tag = 1;
if(!($privacy_max & $album_info[album_tag])) { $allowed_to_tag = 0; }

// GET ALBUM COMMENT PRIVACY
$allowed_to_comment = 1;
if(!($privacy_max & $album_info[album_comments])) { $allowed_to_comment = 0; }


// GET MEDIA COMMENTS
$comment = new se_comment('media', 'media_id', $media_info[media_id]);
$total_comments = $comment->comment_total();


// UPDATE ALBUM VIEWS
if($user->user_info[user_id] != $owner->user_info[user_id]) {
  $album_views_new = $album_info[album_views] + 1;
  $database->database_query("UPDATE se_albums SET album_views='$album_views_new' WHERE album_id='$album_info[album_id]' LIMIT 1");
}

// UPDATE NOTIFICATIONS
if($user->user_info[user_id] == $owner->user_info[user_id]) {
  $database->database_query("DELETE FROM se_notifys USING se_notifys LEFT JOIN se_notifytypes ON se_notifys.notify_notifytype_id=se_notifytypes.notifytype_id WHERE se_notifys.notify_user_id='".$owner->user_info[user_id]."' AND (se_notifytypes.notifytype_name='mediacomment' OR se_notifytypes.notifytype_name='mediatag' OR se_notifytypes.notifytype_name='newtag') AND notify_object_id='".$media_info[media_id]."'");
}



// RETRIEVE TAGS FOR THIS PHOTO
$tag_array = Array();
$tags = $database->database_query("SELECT se_mediatags.*, se_users.user_id, se_users.user_username, se_users.user_fname, se_users.user_lname FROM se_mediatags LEFT JOIN se_users ON se_mediatags.mediatag_user_id=se_users.user_id WHERE mediatag_media_id='$media_info[media_id]' ORDER BY mediatag_id ASC");
while($tag = $database->database_fetch_assoc($tags)) { 

  $taggeduser = new se_user();
  if($tag[user_id] != NULL) {
    $taggeduser->user_exists = 1;
    $taggeduser->user_info[user_id] = $tag[user_id];
    $taggeduser->user_info[user_username] = $tag[user_username];
    $taggeduser->user_info[user_fname] = $tag[user_fname];
    $taggeduser->user_info[user_lname] = $tag[user_lname];
    $taggeduser->user_displayname();
  } else {
    $taggeduser->user_exists = 0;
  }

  $tag[tagged_user] = $taggeduser;
  $tag_array[] = $tag; 
}

// SET PROFILE PHOTO KMODS
if($task == "setprofilephoto") {

	$media_id = $_GET['media_id'];
	$media_ext = $_GET['media_ext'];
	
	if( stristr($user->user_info['user_photo'], 'upload') )
	{
	  $old_photo = substr( strrchr($user->user_info['user_photo'], '/'), 1, strrpos(strrchr($user->user_info['user_photo'], '/'), ".")-7);
	  $thumb_path = $url->url_userdir($album_info['album_user_id']).$media_id."_thumb.jpg";
	}
	else
	{
	  $old_photo = substr($user->user_info[user_photo],0,substr($user->user_info['user_photo'], 0, strrpos($user->user_info['user_photo'], ".")-7));
	  $thumb_path = $url->url_userdir($album_info['album_user_id']).$media_id."_thumb.jpg";
	}
	
	$database->database_query("UPDATE se_users SET user_photo='$thumb_path' WHERE user_id='".$user->user_info[user_id]."'");
	
	// DETERMINE SIZE OF THUMBNAIL TO SHOW IN ACTION
    $photo_width = 100;
    $photo_height = 100;
	
	// INSERT ACTION
    $action_media = Array(Array('media_link'=>$url->url_create('profile', $user->user_info[user_username]), 'media_path'=>$thumb_path, 'media_width'=>$photo_width, 'media_height'=>$photo_height));
    $actions->actions_add($user, "editphoto", Array($user->user_info[user_username], $user->user_displayname), $action_media, 999999999, TRUE, "user", $user->user_info[user_id], $user->user_info[user_privacy]);
	
	// SEND AJAX CONFIRMATION
	echo "<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'><script type='text/javascript'>";
    echo "window.parent.document.getElementById('profilephotomsg_$media_id').innerHTML = '<img style=\'display:block;float:left;margin-right:4px;\' title=\'".SE_Language::get(20000802)."\' src=\'./images/icons/profile_editphoto16.gif\' border=\'0\'>".SE_Language::get(20000803)."';";
	//echo "window.parent.document.getElementById('profilephotomsg_$old_photo').innerHTML = '<a href=\'javascript:void(0);\' onClick=\"\$(\'ajaxframe\').src=\'album_file.php?user=".$owner->user_info['user_username']."&task=setprofilephoto&album_id={$album_info[album_id]}&media_id=$old_photo\';this.blur();\"><img title=\'Set as Profile Photo\' style=\'display:block;float:left;\' src=\'./images/icons/profile_editphoto_dim16.gif\' border=\'0\'></a>';";
	// echo "window.parent.document.getElementById('profilephotomsg_$old_photo').innerHTML = '';";
    echo "</script></head><body></body></html>";
    exit();
}

// SET GLOBAL PAGE TITLE
$global_page_title[0] = 1000158;
$global_page_title[1] = $owner->user_displayname;
$global_page_title[2] = $media_info[media_title];
$global_page_description[0] = 1000159;
$global_page_description[1] = $media_info[media_desc];

// ASSIGN VARIABLES AND DISPLAY ALBUM FILE PAGE
$smarty->assign('album_info', $album_info);
$smarty->assign('media_info', $media_info);
$smarty->assign('total_comments', $total_comments);
$smarty->assign('allowed_to_comment', $allowed_to_comment);
$smarty->assign('allowed_to_tag', $allowed_to_tag);
$smarty->assign('media', $media_array);
$smarty->assign('media_keys', array_keys($media_array));
$smarty->assign('tags', $tag_array);
include "footer.php";
?>