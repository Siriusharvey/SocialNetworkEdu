<?php

include "header.php";

// INSTALL PROFILE PHOTO MOD 

$sql = "ALTER TABLE se_users MODIFY user_photo VARCHAR(50)";
$database->database_query($sql) or die($database->database_error()." ".$sql);

// CREATE LANGUAGE VARS
$sql = "SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 && languagevar_id=20000801 LIMIT 1";
$resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

if( !$database->database_num_rows($resource) )
{
$sql = "
  INSERT INTO `se_languagevars`
	(`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`)
  VALUES 
    (20000801, 1, 'Set as Profile Photo', 'album_file, user_album_update, album'),
	(20000802, 1, 'Your Profile Photo', 'album_file, user_album_update, album'),
	(20000803, 1, 'Profile', 'album_file, user_album_update, album'),
	(20000804, 1, 'To Profile', 'album_file, user_album_update, album'),
	(20000805, 1, 'Or, choose an image from any of <a href=\'user_album.php\'>your albums</a> or <a href=\'browse_albums.php\'>anyone else\'s</a> albums..', 'user_editprofile_photo')
";
$database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
}


echo "
<html>

<head>
<title>Install Profile Photo Mod</title>
</head>

<body>
Profile Photo Mod installed successfully.  Make sure to delete this install file (install_profilephotomod.php).
</body>
</html>";

?>
