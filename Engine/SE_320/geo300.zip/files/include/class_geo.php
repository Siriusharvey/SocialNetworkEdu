<?php

include_once "class_radcodes.php";

class se_geolocation extends rc_model
{
  var $table = 'se_geolocations';
  var $pk = 'geolocation_id';
  
  function FindByPostal($postal, $country = null) {
  	
    $condition = "geolocation_postal = '$postal'";
    if ($country) {
      $condition .= " AND geolocation_country = '$country'";
    }
    
    //rc_toolkit::debug($condition, "se_geolocation :: FindByPostal");
    
    return $this->FindRecordByCriteria($condition);
  }
  
  
  function get_mbr_condition($distance_meters, $tbl_alias=null) {
  	$frag =  se_geo::earth_mbr_sql($this->geolocation_longitude, $this->geolocation_latitude, $distance_meters, $tbl_alias);
  	return $frag;
  }
  
  function get_distance_fragment() {
  	return se_geo::earth_distance_sql($this->geolocation_longitude, $this->geolocation_latitude);
  }
  
  function get_distance_condition($distance_meters) {
  	$frag = $this->get_distance_fragment() . " < $distance_meters";
  	return $frag;
  }
  
  function proximity_distance_search_condition($distance_meters, $tbl_alias=null) {
  	$mbr = $this->get_mbr_condition($distance_meters, $tbl_alias);
  	$dis = $this->get_distance_condition($distance_meters);
  	$condition = "(($mbr) AND ($dis))";
  	return $condition;
  }
  
  function set_within_distance($distance, $unit) {
  	$this->within_distance = se_geo::distance_to_meters($distance, $unit);
  	$this->distance_unit = $unit;
  }
  
  function convert_distance_to_unit($distance_meters) {
  	if ($this->distance_unit == 'km') {
  	  return se_geo::meter_to_km($distance_meters);
  	}
  	else {
  	  return se_geo::meter_to_mile($distance_meters);
  	}
  }
}
// se_geolocation



// $Id: earth.inc,v 1.10 2008/05/20 22:55:25 bdragon Exp $

/**
 * License clarification:
 *
 * On Feb 13, 2005, in message <Pine.LNX.4.58.0502131827510.5072@server1.LFW.org>,
 * the creator of these routines, Ka-Ping Yee, authorized these routines to be
 * distributed under the GPL.
 * This library is an original implementation of UCB CS graduate student, Ka-Ping Yee (http://www.zesty.ca).
 */

/**
 * @file
 * Trigonometry for calculating geographical distances.
 * All function arguments and return values measure distances in metres
 * and angles in degrees.  The ellipsoid model is from the WGS-84 datum.
 * Ka-Ping Yee, 2003-08-11
 */

//$earth_radius_semimajor = 6378137.0;
//$earth_flattening = 1/298.257223563;
//$earth_radius_semiminor = $earth_radius_semimajor * (1 - $earth_flattening);
//$earth_eccentricity_sq = 2*$earth_flattening - pow($earth_flattening, 2);


class se_geo {
  
  function earth_radius_semimajor() {
    return 6378137.0;
  }
  
  function earth_flattening() {
    return (1/298.257223563);
  }
  
  function earth_radius_semiminor() {
    return (se_geo::earth_radius_semimajor() * (1 - se_geo::earth_flattening()));
  }
  
  function earth_eccentricity_sq() {
    return (2*se_geo::earth_flattening() - pow(se_geo::earth_flattening(), 2));
  }
  
  // Latitudes in all of U. S.: from -7.2 (American Samoa) to 70.5 (Alaska).
  // Latitudes in continental U. S.: from 24.6 (Florida) to 49.0 (Washington).
  // Average latitude of all U. S. zipcodes: 37.9.
  
  function earth_radius($latitude=37.9) {
    //global $se_geo::earth_radius_semimajor, $se_geo::earth_radius_semiminor;
    // Estimate the Earth's radius at a given latitude.
    // Default to an approximate average radius for the United States.
  
    $lat = deg2rad($latitude);
  
    $x = cos($lat)/se_geo::earth_radius_semimajor();
    $y = sin($lat)/se_geo::earth_radius_semiminor();
    return 1 / (sqrt($x*$x + $y*$y));
  }
  
  function earth_xyz($longitude, $latitude, $height = 0) {
    // Convert longitude and latitude to earth-centered earth-fixed coordinates.
    // X axis is 0 long, 0 lat; Y axis is 90 deg E; Z axis is north pole.
    //global $se_geo::earth_radius_semimajor, $se_geo::earth_eccentricity_sq;
    $long = deg2rad($longitude);
    $lat = deg2rad($latitude);
  
    $coslong = cos($long);
    $coslat = cos($lat);
    $sinlong = sin($long);
    $sinlat = sin($lat);
    $radius = se_geo::earth_radius_semimajor() /
      sqrt(1 - se_geo::earth_eccentricity_sq() * $sinlat * $sinlat);
    $x = ($radius + $height) * $coslat * $coslong;
    $y = ($radius + $height) * $coslat * $sinlong;
    $z = ($radius * (1 - se_geo::earth_eccentricity_sq()) + $height) * $sinlat;
    return array($x, $y, $z);
  }
  
  function earth_arclength($angle, $latitude=37.9) {
    // Convert a given angle to earth-surface distance.
    return deg2rad($angle) * se_geo::earth_radius($latitude);
  }
  
  function earth_distance($longitude1, $latitude1, $longitude2, $latitude2) {
    // Estimate the earth-surface distance between two locations.
    $long1 = deg2rad($longitude1);
    $lat1 = deg2rad($latitude1);
    $long2 = deg2rad($longitude2);
    $lat2 = deg2rad($latitude2);
    $radius = se_geo::earth_radius(($latitude1 + $latitude2) / 2);
  
    $cosangle = cos($lat1)*cos($lat2) *
      (cos($long1)*cos($long2) + sin($long1)*sin($long2)) +
      sin($lat1)*sin($lat2);
    return acos($cosangle) * $radius;
  }
  
  /*
   * Returns the SQL fragment needed to add a column called 'distance'
   * to a query that includes the location table
   *
   * @param $longitude   The measurement point
   * @param $latibude    The measurement point
   * @param $tbl_alias   If necessary, the alias name of the location table to work from.  Only required when working with named {location} tables
   */
  function earth_distance_sql($longitude, $latitude, $tbl_alias = '') {
    // Make a SQL expression that estimates the distance to the given location.
    $long = deg2rad($longitude);
    $lat = deg2rad($latitude);
    $radius = se_geo::earth_radius($latitude);

    $coslong = cos($long);
    $coslat = cos($lat);
    $sinlong = sin($long);
    $sinlat = sin($lat);
    
    $tbl_alias = empty($tbl_alias) ? $tbl_alias : ($tbl_alias .'.');
    
    $fragment = "(IFNULL(ACOS($coslat*COS(RADIANS({$tbl_alias}geolocation_latitude))*($coslong*COS(RADIANS({$tbl_alias}geolocation_longitude)) + $sinlong*SIN(RADIANS({$tbl_alias}geolocation_longitude))) + $sinlat*SIN(RADIANS({$tbl_alias}geolocation_latitude))), 0.00000)*$radius)";  
    return $fragment;
  }
  
  
  /**
   * Returns the SQL fragment needed for Minimum Boundary Rectangle of location
   * @return string
   */
  function earth_mbr_sql($lon, $lat, $distance_meters, $tbl_alias = '') {
  	
    $latrange = se_geo::earth_latitude_range($lon, $lat, $distance_meters);
    $lonrange = se_geo::earth_longitude_range($lon, $lat, $distance_meters);    
    
    $tbl_alias = empty($tbl_alias) ? $tbl_alias : ($tbl_alias .'.');
    
    $condition = " {$tbl_alias}geolocation_latitude > $latrange[0] AND {$tbl_alias}geolocation_latitude < $latrange[1] AND {$tbl_alias}geolocation_longitude > $lonrange[0] AND {$tbl_alias}geolocation_longitude < $lonrange[1] ";
    
		return $condition;
    
  }
  
  function earth_longitude_range($longitude, $latitude, $distance) {
    // Estimate the min and max longitudes within $distance of a given location.
    $long = deg2rad($longitude);
    $lat = deg2rad($latitude);
    $radius = se_geo::earth_radius($latitude);
  
    $angle = $distance / $radius;
    $diff = asin(sin($angle)/cos($lat));
    $minlong = $long - $diff;
    $maxlong = $long + $diff;
    if ($minlong < -pi()) { $minlong = $minlong + pi()*2; }
    if ($maxlong > pi()) { $maxlong = $maxlong - pi()*2; }
    return array(rad2deg($minlong), rad2deg($maxlong));
  }
  
  function earth_latitude_range($longitude, $latitude, $distance) {
    // Estimate the min and max latitudes within $distance of a given location.
    $long = deg2rad($longitude);
    $lat = deg2rad($latitude);
    $radius = se_geo::earth_radius($latitude);
  
    $angle = $distance / $radius;
    $minlat = $lat - $angle;
    $maxlat = $lat + $angle;
    $rightangle = pi()/2;
    if ($minlat < -$rightangle) { // wrapped around the south pole
      $overshoot = -$minlat - $rightangle;
      $minlat = -$rightangle + $overshoot;
      if ($minlat > $maxlat) { $maxlat = $minlat; }
      $minlat = -$rightangle;
    }
    if ($maxlat > $rightangle) { // wrapped around the north pole
      $overshoot = $maxlat - $rightangle;
      $maxlat = $rightangle - $overshoot;
      if ($maxlat < $minlat) { $minlat = $maxlat; }
      $maxlat = $rightangle;
    }
    return array(rad2deg($minlat), rad2deg($maxlat));
  }


	function distance_to_meters($distance, $unit = 'mi')
	{
	  if (!is_numeric($distance)) {
	    return NULL;
	  }
	
	  if ($unit != 'km' && $unit != 'mile' && $unit != 'mi') {
	    $unit = 'km';
	  }
	
	  $result = round(floatval($distance) * (($unit == 'km') ? 1000.0 : 1609.347), 2);
	  return $result;
	}
  // distance_to_meters
  
	
	function meter_to_km($distance)
	{
	  return round(floatval($distance) / 1000.0, 2);
	}
	
	
	function meter_to_mile($distance)
	{
		return round(floatval($distance) / 1609.347, 2);
	}
	

	
}
// se_geo