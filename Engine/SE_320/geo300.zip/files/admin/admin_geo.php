<?php

$page = "admin_geo";
include "admin_header.php";

$task = rc_toolkit::get_request('task','main');

$result = 0;

if ($task == 'dosave') {
  
  $setting['setting_geo_distance_unit'] = rc_toolkit::get_post('setting_geo_distance_unit','mi');
  
  $sql = "UPDATE se_settings SET 
          setting_geo_distance_unit='$setting[setting_geo_distance_unit]'
          ";
    
    $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
          
          
    $result = 1;
}

$smarty->assign('units', array('mi','km'));
$smarty->assign('result', $result);

include "admin_footer.php";
