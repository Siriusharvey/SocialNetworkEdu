<?php
$page = "admin_geo_locations";
include "admin_header.php";

$result = 0;
$task = rc_toolkit::get_request('task','main');
$p = rc_toolkit::get_request('p',1);

$rc_validator = new rc_validator();


$se_geolocation = new se_geolocation();


$form_keys = array('postal','city','province','latitude','longitude','country');

if ($task == 'create') {

  foreach ($form_keys as $key) {
    $data["geolocation_$key"] = rc_toolkit::get_request("geolocation_$key");
  }
   
  //$location = $se_geolocation->FindByItemTypeAndItemID($data['geolocation_item_type'],$data['geolocation_item_id']);
  
  $geolocation_id = rc_toolkit::get_request('geolocation_id',0);
  
  if ($geolocation_id) {
    $location = $se_geolocation->FindById($geolocation_id);
  }
  if (!$location) {
    $location = new se_geolocation();
  }
  
  $location->setProperties($data);
  $id = $location->save();
    
  if ($id) {
    $result = 11300032;  
  }
  else {
    $is_error = 11300027;
  }
  


}

else if ($task == 'delete') {
  $sid = rc_toolkit::get_request('geolocation_id');
  $location = $se_geolocation->FindById($sid);
  if ($location) {
    $location->delete();
    $result = 11300034;
  }
}

else if ($task == 'delete_all') {
  $database->database_query("DELETE FROM se_geolocations");
  $result = 11300049;
}


$search_keys = array('postal','city','province','latitude','longitude','country');

$cs = array();

foreach ($search_keys as $skey) {
  
  $sval = trim(rc_toolkit::get_request("f_$skey"));
  if (strlen($sval)) {
    if ($skey == 'user_username') {
      $cs[$skey] = "$skey LIKE '%$sval%'";
    }
    else {
      $cs[$skey] = "geolocation_$skey LIKE '%$sval%'";
    }
    
    $smarty->assign("f_$skey", $sval);
  }
  
}


$s_col = rc_toolkit::get_request('s_col','geolocation_id');
$s_by = rc_toolkit::get_request('s_by','asc');


$where = rc_toolkit::criteria_builder($cs,'AND',true);

//rc_toolkit::debug($cs,"$where");

$total_locations = $se_geolocation->CountByCriteria($where);

//rc_toolkit::debug($amount_locations);

$trans_per_page = 100;
$page_vars = make_page($total_locations, $trans_per_page, $p);

$page_array = Array();
for($x=0;$x<=$page_vars[2]-1;$x++) {
  if($x+1 == $page_vars[1]) { $link = "1"; } else { $link = "0"; }
  $page_array[$x] = Array('page' => $x+1,
        'link' => $link);
}

$where .= " ORDER BY $s_col $s_by LIMIT $page_vars[0], $trans_per_page";
$locations = $se_geolocation->FindRecordsByCriteria($where);

//rc_toolkit::debug($rc_location->FindExpiresPaidRecords());

$smarty->assign('se_geolocation', $se_geolocation);
$smarty->assign('s_col',$s_col);
$smarty->assign('s_by', $s_by);
$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);

$smarty->assign('locations', $locations);
$smarty->assign('total_locations', $total_locations);

$smarty->assign('p', $p);
$smarty->assign('pages', $page_array);
include "admin_footer.php";
