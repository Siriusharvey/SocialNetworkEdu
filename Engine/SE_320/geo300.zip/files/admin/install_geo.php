<?php

$plugin_name = "Geo Location Module";
$plugin_version = "3.0"; //2.". ((int)( time() / 100));
$plugin_type = "geo";
$plugin_desc = "This plugin provides an uniform interface to handle geo location for various of Radcodes plugins.";
$plugin_icon = "geo_geo16.gif";
$plugin_menu_title = "11300001"; 
$plugin_pages_main = "11300002<!>geo_geo16.gif<!>admin_geo_import.php<~!~>11300003<!>geo_geo16.gif<!>admin_geo_locations.php<~!~>11300001<!>geo_geo16.gif<!>admin_geo.php<~!~>";
$plugin_pages_level = "";
$plugin_url_htaccess = "";

// lang var = 1130XXXX

$plugin_db_charset = 'utf8';
$plugin_db_collation = 'utf8_unicode_ci';

if($install == "geo") {

  if (!class_exists('rc_toolkit')) {
    $message = '<p>You must install <b>Radcodes Core Library</b> prior to install this plugin. You can download it in <a href="http://www.radcodes.com/shop/">Radcodes Shop Customer Area</a> for FREE.</p>';  
    die($message);
  }
  
  rc_toolkit::validate_plugin_requirements($plugin_type, array('radcodes'=>3.27));
  
  unset($_SESSION['RC_MODEL_CACHE']);
   
  //######### INSERT ROW INTO se_plugins
  $sql = "SELECT NULL FROM se_plugins WHERE plugin_type='$plugin_type'";
  $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  
  if( !$database->database_num_rows($resource) )
  {
    $sql = "
      INSERT INTO se_plugins (
        plugin_name,
        plugin_version,
        plugin_type,
        plugin_desc,
        plugin_icon,
        plugin_menu_title,
        plugin_pages_main,
        plugin_pages_level,
        plugin_url_htaccess
      ) VALUES (
        '$plugin_name',
        '$plugin_version',
        '$plugin_type',
        '".str_replace("'", "\'", $plugin_desc)."',
        '$plugin_icon',
        '$plugin_menu_title',
        '$plugin_pages_main',
        '$plugin_pages_level',
        '$plugin_url_htaccess'
      )
    ";
    
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  }
  //######### UPDATE PLUGIN VERSION IN se_plugins
  else
  {
    $sql = "
      UPDATE
        se_plugins
      SET
        plugin_name='$plugin_name',
        plugin_version='$plugin_version',
        plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
        plugin_icon='$plugin_icon',
        plugin_menu_title='$plugin_menu_title',
        plugin_pages_main='$plugin_pages_main',
        plugin_pages_level='$plugin_pages_level',
        plugin_url_htaccess='$plugin_url_htaccess'
      WHERE
        plugin_type='$plugin_type'
    ";
    
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  }


  
  
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_geolocations'")) == 0) {
    
    $sql = "CREATE TABLE `se_geolocations` (
      `geolocation_id` int(9) NOT NULL auto_increment,
      `geolocation_postal` varchar(16) NOT NULL default '',
      `geolocation_city`   varchar(64) NOT NULL default '',
      `geolocation_province` varchar(64) NOT NULL default '',
      `geolocation_latitude` decimal(10,6) NOT NULL DEFAULT '0',
      `geolocation_longitude` decimal(10,6) NOT NULL DEFAULT '0',
      `geolocation_country` varchar(32) NOT NULL default '',
      PRIMARY KEY  (`geolocation_id`),
      UNIQUE KEY `postalcountrycityprovince` (`geolocation_postal`,`geolocation_country`,`geolocation_city`,`geolocation_province`),
			  KEY `postal` (`geolocation_postal`),
			  KEY `lat` (`geolocation_latitude`),
			  KEY `long` (`geolocation_longitude`),
			  KEY `country` (`geolocation_country`)
    )
    CHARACTER SET {$plugin_db_charset} COLLATE {$plugin_db_collation}
    ";
   
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

  }
  
  
  
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_settings LIKE 'setting_geo_distance_unit'")) == 0) {
    
    $sql = "ALTER TABLE se_settings 
          ADD COLUMN `setting_geo_distance_unit` varchar(60) NOT NULL default 'mi'
    ";
    
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  }    
  
  /*
  //// ////////////////////// ---- temp clear -------------------------
  $lang_min_id = 11300001;
  $lang_max_id = 11300999;
  
  $sql = "DELETE FROM se_languagevars WHERE languagevar_id >= $lang_min_id AND languagevar_id <= $lang_max_id";
  $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    //// ////////////////////// ---- temp clear -------------------------
  */


  if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=11300001 LIMIT 1")) == 0) {
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES 
(11300001, 1, 'Global Geo Settings', ''),
(11300002, 1, 'Geo Import', ''),
(11300003, 1, 'Geo Locations', ''),
(11300004, 1, 'Geo locations imported successfully.', ''),

(11300005, 1, 'Import Geo Locations', ''),
(11300006, 1, 'This page allow you to import geo locations that would be used to perform location search.', ''),
(11300007, 1, 'Location Pack', ''),
(11300008, 1, 'Please select the location pack you would like to import.<br>It may take a while to import all the locations, please be patient while it does the works. Do NOT close or refresh the browser until the process is done!', ''),
(11300009, 1, 'Import Now', ''),
(11300010, 1, 'Geo Locations', ''),
(11300011, 1, 'All geo locations available in your system are listed below.', ''),
(11300012, 1, 'View Locations', ''),
(11300013, 1, 'No locations found in database.', ''),
(11300014, 1, 'ID', ''),
(11300015, 1, 'Zip / Postal Code', ''),
(11300016, 1, 'City', ''),
(11300017, 1, 'State / Province', ''),
(11300018, 1, 'Latitude', ''),
(11300019, 1, 'Longitude', ''),
(11300020, 1, 'Country', ''),
(11300021, 1, 'Options', ''),
(11300022, 1, 'edit', ''),
(11300023, 1, 'delete', ''),
(11300024, 1, '%1\$s locations', ''),
(11300025, 1, 'Page', ''),
(11300026, 1, 'Add New Location', ''),
(11300027, 1, 'Save failed.', ''),

(11300030, 1, 'Delete Location', ''),
(11300031, 1, 'Add Location', ''),
(11300032, 1, 'Location saved successfully.', ''),
(11300033, 1, 'Update Location', ''),
(11300034, 1, 'Location deleted successfully.', ''),
(11300035, 1, 'Do you really want to delete this location?', ''),
(11300036, 1, 'Please fill out the form below, the combination of Zip/Postal Code and Country must be unique.', ''),
(11300037, 1, 'Abbreviation code, ex: &quot;CA&quot; for California', ''),
(11300038, 1, 'Two lowercase-letter ISO country code.<br>Ex: &quot;us&quot; for United States', ''),
(11300039, 1, '<strong>NOTE:</strong> The installation of Radcodes Geo Module does not come with geo location database. You can populate this database for whatever countries / locations that fit your needs by using one/combination of these methods', ''),
(11300040, 1, 'Purchase Geo Location Import Packages for <a href=\"http://www.radcodes.com/plugin/geo_db_usa\" target=\"_blank\">United States</a> and/or <a href=\"http://www.radcodes.com/plugin/geo_db_int\" target=\"_blank\">Internation</a> on Radcodes Store.<br><i>This is highly recommended because it\'s the fastest and safest method.</i>', ''),
(11300041, 1, 'Search around the web for zip / postal codes database, and do the import yourself.<br><i>This requires you to understand the database structure, and perhaps some programming skills.</i>', ''),
(11300042, 1, 'Manually add geo locations yourself by click on \"<b>Add New Location</b>\" link below.<br><i>This may take a while to enter more than 40000 records for USA</i>', ''),

(11300043, 1, 'Global Geo Settings', ''),
(11300044, 1, 'This page contains settings that affect geo of your entire social network.', ''),
(11300045, 1, 'General Settings', ''),
(11300046, 1, 'Please select the default unit for distance (mile or kilometer)', ''),
(11300047, 1, 'Delete ALL Locations', ''),
(11300048, 1, 'WARNING: This step cannot be undone!<br><br>Do you really want to ALL locations?', ''),
(11300049, 1, 'All locations have been deleted.', '')

      ") or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br />");
  }



### LANGUAGE PLACEHOLDER ###






  
  
}  

