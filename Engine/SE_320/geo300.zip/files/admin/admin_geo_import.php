<?php

set_time_limit(0);

$page = "admin_geo_import";

include "admin_header.php";


$geo_packs = array();
$geo_pack_dir = './import_geo/';
if($handle = opendir($geo_pack_dir))
{
  while(($file = readdir($handle)) !== false)
  {
    if($file != '.' && $file != '..')
    {
      if (strstr($file, 'geo_') and strstr($file, '.csv')) {
        $geo_packs[$file] = $file;
      }
    }
  }
  closedir($handle);
}

$task = rc_toolkit::get_request('task', 'main');

$geo_pack_script = rc_toolkit::get_request('geo_pack_script');


if ($task == 'doimport' && $geo_pack_script) {
  
  echo "<pre>--- START IMPORT - DO NOT REFRESH OR CLOSE BROWSE UNTIL YOU SEE -- 'IMPORT PROCESS COMPLETED' MESSAGE ----------\n";
  
  $valid_columns = array('postal','city','province','latitude','longitude','country');
  
  $file = $geo_pack_dir.$geo_pack_script;
	$row = 0;
	$handle = fopen($file, "r");
	
	while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
	  if ($row == 0) {
	    $headers = array();
	    foreach ($data as $k => $v) {
	      if (in_array($v, $valid_columns)) {
	        $headers[$k] = "geolocation_$v";
	      }
	    }
	  }
	  else {
	    $info = array();
	    foreach ($headers as $k => $v) {
	      $info[$v] = $data[$k];
	    }
	    
	    $data_str = rc_toolkit::db_data_packer($info);
	    $sql = "INSERT INTO se_geolocations SET $data_str";
	    
	    $database->database_query($sql) or print("\n\n---- Error: ".$database->database_error()."\nQuery: ".$sql."\n----------\n");
	  
	  }
	  $row++;
    echo "\nRow $row";
    flush();
	}
	fclose($handle);  

	echo "\n\n------IMPORT PROCESS COMPLETED ----------------------------";
  echo "\n\n<span style='color: red; font-size: 14px'>Do NOT refresh your browse. <a href='admin_geo_import.php'>Click Here to go back to Geo Import</a> page</span>";
	exit;
  $result = 11300004;
}

$smarty->assign('geo_packs', $geo_packs);
$smarty->assign('task', $task);
$smarty->assign('error', $error);
$smarty->assign('result', $result);
include "admin_footer.php";
